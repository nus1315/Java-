/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
public class Main {
    public static void main(String[] args) {
        Shape circle = new Circle(5, "RED", false);
        Shape rectangle = new Rectangle(4, 2.0, "RED", false);
        Shape box = new Box(3, 3, 3);

        System.out.println("Circle");
        circle.printInfo();

        System.out.println("\nRectangle");
        rectangle.printInfo();

        System.out.println("\nBox");
        box.printInfo();
    }
}
