

public class JavaApplication7 {

    public static void main(String[] args) {
        // TODO code application logic here
        login LoginFrame = new login();
        LoginFrame.setVisible(true);
        LoginFrame.pack();
        LoginFrame.setLocationRelativeTo(null);
    }
    
}
