/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
public class Car implements Vehicle {
    @Override
    public void startEngine() {
      System.out.println("brvooormmmm!");
    }

    @Override
    public void stopEngine() {
        System.out.println("Zrrrrrrrrr");
    }

    @Override
    public int getNumberOfWheels() {
        return 4;
   }
    
}
