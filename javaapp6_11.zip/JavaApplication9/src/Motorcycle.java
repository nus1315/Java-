/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
public class Motorcycle implements Vehicle {
    @Override
    public void startEngine() {
        System.out.println("Hhhhhhhh");
    }

    @Override
    public void stopEngine() {
        System.out.println("zrr");
    }

    @Override
    public int getNumberOfWheels() {
        return 2;
    }
    
}
