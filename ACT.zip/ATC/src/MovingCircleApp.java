/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class MovingCircleApp extends JFrame implements KeyListener {
    private int x = 185;
    private int y = 185;
    private final int circleDiameter = 30;

    public MovingCircleApp() {
        // Set the title of the frame
        setTitle("Moving Circle Application");

        // Set the size of the frame
        setSize(400, 400);

        // Specify the layout manager
        setLayout(null);

        // Ensure the application exits when the frame is closed
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Add the key listener to the frame
        addKeyListener(this);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        // Draw the circle at the current (x, y) position
        g.setColor(Color.BLUE);
        g.fillOval(x, y, circleDiameter, circleDiameter);
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // Not used in this example
    }

    @Override
    public void keyPressed(KeyEvent e) {
        // Update the position based on the arrow key pressed
        System.out.println(e.getKeyCode());
        //x += 10;
        //y += 10;
        
        int input = e.getKeyCode();
        switch (input) {
            case 38 -> y = y-10;
            case 37 -> x = x-10;
            case 39 -> x = x+10;
            case 40 -> y = y+10;
            default -> {
            }
        }
                
        // Repaint the frame to reflect the new position
        repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // Not used in this example
    }

    public static void main(String[] args) {
        // Create an instance of the MovingCircleApp class
        MovingCircleApp frame = new MovingCircleApp();

        // Make the frame visible
        frame.setVisible(true);
    }
}
