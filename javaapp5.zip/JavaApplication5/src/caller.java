
import java.awt.FlowLayout;
import javax.swing.JFrame;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
public class caller {
    public static void main(String[] args) {
        
    }
            
}
class x extends JFrame{
    public x(){
        JButton b =new JButton("ADD Form");
        b.addAtionListener(new ActionListener(){
            @override
            public void actionPerformed(ActionEvent e){
                throw new UnsupportedOperationException("Not supported yet");
            }
        });
                
        setLayout(new FlowLayout());
        setVisible(true);
        setSize(400,400);
        setDefaultCloseOpertion(JFrame.EXIT_ON_CLOSE);
    }

    private void setLayout(FlowLayout flowLayout) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void setDefaultCloseOpertion(int EXIT_ON_CLOSE) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static class ActionListener {

        public ActionListener() {
        }
    }

    private static class JButton {

        public JButton(String add_Form) {
        }

        private void addAtionListener(ActionListener actionListener) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }

    private static class ActionEvent {

        public ActionEvent() {
        }
    }
}